/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accountlogin;

/**
 *
 * @author Yusuf
 */
// I created a food class to set arraylist
public class Food {
    String category;
    String name;
    int unit;
    double price;
    
    public Food(String category, String name, int unit, double price){
        this.category = category;
        this.name = name;
        this.unit = unit;
        this.price = price;
    }
    
}
