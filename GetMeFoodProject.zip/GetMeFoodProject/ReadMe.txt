1- Get Me Food is our application in Executable jar file

2- AccountLogin is Get Me Food with its source code. AccountLogin is named when this project is stared

3- There could be delay and minor bug. We apologize for this already
